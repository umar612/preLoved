import 'package:flutter/material.dart';
import '../../widgets/product_card.dart';
import '../../widgets/category_chip.dart'; // Added import for CategoryChip

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar( // Replaced CustomAppBar with standard AppBar
        title: const Text('Pre-Loved Finds'),
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Categories',
                    style: Theme.of(context).textTheme.titleLarge, // Replaced headline6
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 50,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [ // Removed const from list literal
                        CategoryChip(label: 'Women'),
                        CategoryChip(label: 'Men'),
                        CategoryChip(label: 'Kids'),
                        CategoryChip(label: 'Accessories'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16.0),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.7,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              delegate: SliverChildBuilderDelegate(
                    (context, index) => const ProductCard(),
                childCount: 6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}