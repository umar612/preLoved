import 'package:flutter/material.dart';
import '../models/product_model.dart';

class DummyDataProvider with ChangeNotifier {
  List<Product> _products = [
    Product(
      id: '1',
      title: 'Vintage Denim Jacket',
      description: 'Classic vintage denim jacket with slight wear',
      price: 45.99,
      images: ['https://picsum.photos/200'],
      category: 'Women',
      rating: 4.5,
      reviews: 23,
    ),
    Product(
      id: '2',
      title: 'Leather Crossbody Bag',
      description: 'Genuine leather crossbody bag in brown',
      price: 65.99,
      images: ['https://picsum.photos/200'],
      category: 'Accessories',
      rating: 4.8,
      reviews: 15,
    ),
    // Add more dummy products as needed
  ];

  List<Product> get products => _products;

  void addProduct(Product product) {
    _products.add(product);
    notifyListeners();
  }
}